/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dajose-p <dajose-p@student.42madrid.c      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/23 21:51:27 by dajose-p          #+#    #+#             */
/*   Updated: 2024/09/26 06:43:07 by dajose-p         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char const	*ft_trim_check(char const *s1, char const *set)
{
	while (*s1 == *set)
	{
		s1++;
		set++;
	}
	return (s1);
}

int	ft_trim_counter(char const *s1, char const *set)
{
	int	count;
	int	i;
	int	j;

	count = 0;
	i = 0;
	j = 0;
	while (s1[i] != '\0')
	{
		while (s1[i] == set[j])
		{
			count++;
			i++;
			j++;
		}
		i++;
	}
	return (count);
}

int	ft_strlen(char const *s)
{
	int	i;

	i = 0;
	while (s[i] != '\0')
		i++;
	return (i);
}

char	*ft_strtrim(char const *s1, char const *set)
{
	int		i;
	int		count;
	char	*str;

	i = 0;
	count = ft_trim_counter(s1, set);
	str = malloc((ft_strlen(s1) - count + 1) * sizeof(char));
	if (str == NULL)
	{
		str = malloc(1);
		return (str);
	}
	i = 0;
	while (*s1 != '\0')
	{
		s1 = ft_trim_check(s1, set);
		str[i] = *s1;
		s1++;
		i++;
	}
	str[i] = '\0';
	return (str);
}
