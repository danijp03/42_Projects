/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dajose-p <dajose-p@student.42madrid.c      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/24 18:48:19 by dajose-p          #+#    #+#             */
/*   Updated: 2024/09/24 22:00:51 by dajose-p         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	count_words(char const *s, char c)
{
	int	i;
	int	co;

	i = 0;
	co = 0;
	while (s[i] != '\0')
	{
		while (s[i] == c)
		{
			i++;
			while ((s[i] >= '!' && s[i] <= '~') && (s[i] != c))
				i++;
			while (s[i] == c)
				i++;
			co++;
		}
	}
	return (co);
}

int	count_words_sp(char const *s, char c, int pos)
{
	int	i;
	int	co;
	int	li;

	i = 0;
	co = 0;
	li = 0;
	while (s[i] != '\0' && li < pos)
	{
		co = 0;
		while (s[i] == c)
			i++;
		while ((s[i] >= '!' && s[i] <= '~') && (s[i] != c))
		{
			co++;
			i++;
		}
		while (s[i] == c)
			i++;
		li++;
	}
	return (co);
}

char	**allocate_memory(char const *s, char c)
{
	int		i;
	char	**arr;

	i = 0;
	arr = malloc((count_words(s, c) + 1) * sizeof(char *));
	if (arr == NULL)
		return (NULL);
	while (i < count_words(s, c))
	{
		arr[i] = malloc((count_words_sp(s, c, i) + 1) * sizeof(char));
		if (arr[i] == NULL)
			return (NULL);
		i++;
	}
	arr[i] = NULL;
	return (arr);
}

void	fill_array(char **arr, char const *s, char c)
{
	int	i;
	int	j;
	int	k;

	i = 0;
	j = 0;
	k = 0;
	while (s[i] != '\0')
	{
		while (s[k] == c)
			k++;
		while ((s[k] >= '!' && s[k] <= '~') && (s[k] != c))
		{
			arr[i][j] = s[k];
			j++;
			k++;
		}
		arr[i][j] = '\0';
		i++;
		j = 0;
	}
}

char	**ft_split(char const *s, char c)
{
	char	**arr;

	arr = allocate_memory(s, c);
	if (arr == NULL)
		return (NULL);
	fill_array(arr, s, c);
	return (arr);
}
